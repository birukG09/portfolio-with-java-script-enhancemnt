/**
 * Animations for the portfolio website
 * This file contains specialized animations beyond the core functionality
 */

// Wait for the DOM to be fully loaded
document.addEventListener('DOMContentLoaded', function() {
    // ===== Hero section animations =====
    function animateHeroSection() {
        const heroTitle = document.querySelector('.hero__title');
        const heroSubtitle = document.querySelector('.hero__subtitle');
        const heroButtons = document.querySelectorAll('.hero__actions .btn');
        const profileImage = document.querySelector('.profile-image');
        
        // Simple fade-in and slide-up animation
        if (heroTitle) {
            heroTitle.style.opacity = '0';
            heroTitle.style.transform = 'translateY(20px)';
            
            setTimeout(() => {
                heroTitle.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
                heroTitle.style.opacity = '1';
                heroTitle.style.transform = 'translateY(0)';
            }, 300);
        }
        
        if (heroSubtitle) {
            heroSubtitle.style.opacity = '0';
            
            setTimeout(() => {
                heroSubtitle.style.transition = 'opacity 0.6s ease';
                heroSubtitle.style.opacity = '1';
                
                // Start typing animation after subtitle appears
                const text = heroSubtitle.textContent;
                heroSubtitle.textContent = '';
                
                let i = 0;
                function typeWriter() {
                    if (i < text.length) {
                        heroSubtitle.textContent += text.charAt(i);
                        i++;
                        setTimeout(typeWriter, 50);
                    }
                }
                
                typeWriter();
            }, 600);
        }
        
        // Animate buttons
        if (heroButtons.length > 0) {
            heroButtons.forEach((btn, index) => {
                btn.style.opacity = '0';
                btn.style.transform = 'translateY(20px)';
                
                setTimeout(() => {
                    btn.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
                    btn.style.opacity = '1';
                    btn.style.transform = 'translateY(0)';
                }, 900 + (index * 200));
            });
        }
        
        // Animate profile image
        if (profileImage) {
            profileImage.style.opacity = '0';
            profileImage.style.transform = 'scale(0.9)';
            
            setTimeout(() => {
                profileImage.style.transition = 'opacity 0.8s ease, transform 0.8s ease';
                profileImage.style.opacity = '1';
                profileImage.style.transform = 'scale(1)';
            }, 800);
        }
    }
    
    // ===== Observer for section animations =====
    function setupSectionAnimations() {
        const sections = document.querySelectorAll('.section');
        
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('section--visible');
                }
            });
        }, { threshold: 0.1 });
        
        sections.forEach(section => {
            section.classList.add('section--hidden');
            observer.observe(section);
        });
    }
    
    // Initialize animations
    animateHeroSection();
    setupSectionAnimations();
    
    // Add subtle parallax effect to the abstract design elements
    window.addEventListener('mousemove', function(e) {
        const heroDesign = document.querySelector('.hero::before');
        const projectsDesign = document.querySelector('.projects::after');
        
        if (heroDesign) {
            const moveX = (e.clientX - window.innerWidth / 2) * 0.01;
            const moveY = (e.clientY - window.innerHeight / 2) * 0.01;
            
            heroDesign.style.transform = `translate(${moveX}px, ${moveY}px)`;
        }
        
        if (projectsDesign) {
            const moveX = (e.clientX - window.innerWidth / 2) * -0.005;
            const moveY = (e.clientY - window.innerHeight / 2) * -0.005;
            
            projectsDesign.style.transform = `rotate(180deg) translate(${moveX}px, ${moveY}px)`;
        }
    });
});