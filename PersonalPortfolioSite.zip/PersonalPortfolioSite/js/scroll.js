/**
 * Smooth scrolling functionality for the portfolio website
 */

document.addEventListener('DOMContentLoaded', function() {
    // Get all navigation links that point to sections (hash links)
    const navLinks = document.querySelectorAll('a[href^="#"]');
    
    // Add click event listener to each link
    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            // Check if this is a hash link to a section
            const href = this.getAttribute('href');
            if (href.startsWith('#') && href.length > 1) {
                e.preventDefault();
                
                // Get the target section
                const targetId = href.substring(1);
                const targetSection = document.getElementById(targetId);
                
                if (targetSection) {
                    // Close mobile menu if it's open
                    const navToggle = document.getElementById('nav-toggle');
                    if (navToggle && navToggle.checked) {
                        navToggle.checked = false;
                    }
                    
                    // Scroll smoothly to the target section
                    window.scrollTo({
                        top: targetSection.offsetTop - 80, // Account for fixed header
                        behavior: 'smooth'
                    });
                    
                    // Update active state of navigation links
                    updateActiveNavLink(href);
                }
            }
        });
    });
    
    // Function to update active navigation link based on current section
    function updateActiveNavLink(currentHash) {
        // Remove active class from all links
        navLinks.forEach(link => {
            link.classList.remove('active');
        });
        
        // Add active class to current link
        const currentLink = document.querySelector(`a[href="${currentHash}"]`);
        if (currentLink) {
            currentLink.classList.add('active');
        }
    }
    
    // Update active navigation link on scroll
    window.addEventListener('scroll', function() {
        // Get all sections
        const sections = document.querySelectorAll('section[id]');
        
        // Find the current section (the one most visible in the viewport)
        let currentSection = '';
        let minDistance = Number.MAX_VALUE;
        
        sections.forEach(section => {
            const sectionTop = section.offsetTop;
            const sectionHeight = section.offsetHeight;
            const scrollPosition = window.scrollY + 100; // Adjust for header
            
            // Calculate how far we are from the middle of this section
            const distance = Math.abs((sectionTop + sectionHeight / 2) - (scrollPosition + window.innerHeight / 2));
            
            // If this is the closest section to the middle of the viewport, update currentSection
            if (distance < minDistance) {
                minDistance = distance;
                currentSection = `#${section.getAttribute('id')}`;
            }
        });
        
        // Update active link based on current section
        if (currentSection) {
            updateActiveNavLink(currentSection);
        }
    });
});