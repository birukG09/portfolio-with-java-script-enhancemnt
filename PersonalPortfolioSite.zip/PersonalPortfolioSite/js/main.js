/**
 * Main JavaScript file for the portfolio website
 * This handles core functionality like skill bar animation, 
 * project filtering, and other interactive elements
 */

document.addEventListener('DOMContentLoaded', function() {
    // ===== Header behavior on scroll =====
    function handleHeaderScroll() {
        const header = document.querySelector('.header');
        const scrollPosition = window.scrollY;
        
        if (scrollPosition > 100) {
            header.classList.add('header--scrolled');
        } else {
            header.classList.remove('header--scrolled');
        }
    }
    
    // Add scroll event listener
    window.addEventListener('scroll', handleHeaderScroll);
    
    // ===== Skill bars animation =====
    function animateSkillBars() {
        const skillBars = document.querySelectorAll('.skill-progress');
        
        // Set up Intersection Observer to animate skill bars when they come into view
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const progressBar = entry.target;
                    const progressValue = progressBar.getAttribute('data-progress');
                    
                    if (progressValue) {
                        setTimeout(() => {
                            progressBar.style.width = progressValue;
                        }, 200);
                    }
                    
                    // Stop observing once animated
                    observer.unobserve(progressBar);
                }
            });
        }, { threshold: 0.2 });
        
        // Start observing each skill bar
        skillBars.forEach(bar => {
            observer.observe(bar);
        });
    }
    
    // Initialize skill bars animation
    animateSkillBars();
    
    // ===== Project filtering =====
    const filterButtons = document.querySelectorAll('.filter-btn');
    const projectCards = document.querySelectorAll('.project-card');
    
    // Add click event to each filter button
    filterButtons.forEach(button => {
        button.addEventListener('click', function() {
            // Remove active class from all buttons
            filterButtons.forEach(btn => btn.classList.remove('active'));
            
            // Add active class to clicked button
            this.classList.add('active');
            
            // Get the filter value
            const filter = this.getAttribute('data-filter');
            
            // Show/hide project cards based on filter
            projectCards.forEach(card => {
                if (filter === 'all') {
                    card.style.display = 'block';
                    
                    // Add animation for appearing cards
                    setTimeout(() => {
                        card.style.opacity = '1';
                        card.style.transform = 'translateY(0)';
                    }, 100);
                } else {
                    const tags = card.getAttribute('data-tags')?.split(',') || [];
                    
                    if (tags.includes(filter)) {
                        card.style.display = 'block';
                        
                        // Add animation for appearing cards
                        setTimeout(() => {
                            card.style.opacity = '1';
                            card.style.transform = 'translateY(0)';
                        }, 100);
                    } else {
                        card.style.opacity = '0';
                        card.style.transform = 'translateY(20px)';
                        
                        // Hide after animation completes
                        setTimeout(() => {
                            card.style.display = 'none';
                        }, 300);
                    }
                }
            });
            
            // Show notification
            showNotification(`Showing ${filter === 'all' ? 'all projects' : filter + ' projects'}`, 'info');
        });
    });
    
    // ===== Contact form handling =====
    const contactForm = document.querySelector('.contact-form');
    
    if (contactForm) {
        contactForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Get form values
            const name = this.querySelector('input[name="name"]').value;
            const email = this.querySelector('input[name="email"]').value;
            const message = this.querySelector('textarea[name="message"]').value;
            
            // Validate form fields
            if (!name || !email || !message) {
                showNotification('Please fill in all fields', 'error');
                return;
            }
            
            // Email validation with regex
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailRegex.test(email)) {
                showNotification('Please enter a valid email address', 'error');
                return;
            }
            
            // In a real scenario, send form data to server
            // For demo, just show success message
            showNotification('Thanks for your message! I\'ll get back to you soon.', 'success');
            
            // Reset form
            this.reset();
            
            // Log the form submission (for demonstration)
            console.log({
                name,
                email,
                message,
                timestamp: new Date().toISOString()
            });
        });
    }
    
    // ===== Notification system =====
    function showNotification(message, type = 'info') {
        // Create notification element
        const notification = document.createElement('div');
        notification.className = `notification notification--${type}`;
        notification.textContent = message;
        
        // Add to document
        document.body.appendChild(notification);
        
        // Trigger animation
        setTimeout(() => {
            notification.classList.add('notification--visible');
        }, 10);
        
        // Remove after timeout
        setTimeout(() => {
            notification.classList.remove('notification--visible');
            
            // Remove from DOM after animation completes
            setTimeout(() => {
                document.body.removeChild(notification);
            }, 300);
        }, 3000);
    }
    
    // Make notification function globally available
    window.showNotification = showNotification;
    
    // ===== Typewriter effect =====
    const typewriterElements = document.querySelectorAll('[data-typewriter]');
    
    typewriterElements.forEach(element => {
        const text = element.textContent;
        element.textContent = '';
        
        let i = 0;
        function typeWriter() {
            if (i < text.length) {
                element.textContent += text.charAt(i);
                i++;
                setTimeout(typeWriter, 100);
            }
        }
        
        typeWriter();
    });
});